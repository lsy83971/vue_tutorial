#!/usr/bin/env node
var x;
x = require('./package');
console.log(x.version)
